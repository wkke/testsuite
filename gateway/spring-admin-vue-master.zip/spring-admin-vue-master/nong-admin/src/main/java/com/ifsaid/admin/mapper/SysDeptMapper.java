package com.ifsaid.admin.mapper;

import com.ifsaid.admin.common.mapper.BaseMapper;
import com.ifsaid.admin.entity.SysDept;

public interface SysDeptMapper extends BaseMapper<SysDept, Integer> {
}
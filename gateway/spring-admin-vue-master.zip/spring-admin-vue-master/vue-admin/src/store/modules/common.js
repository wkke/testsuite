const common = {
  state: {
    website: {
      title: '如果说后台管理系统',
      logo: '/static/logo.png'
    }
  },
  actions: {},
  mutations: {

  }
}
export default common

<!--  -->
<template>
  <div>
    401
  </div>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  computed: {},
  created() {},
  mounted() {},
  methods: {}
}

</script>
<style lang='scss' scoped>
</style>

<!--  -->
<template>
  <div>
    微信设置
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
    }
  },
  created() {},
  mounted() {},
  methods: {}
}

</script>
<style lang='scss' scoped>
</style>

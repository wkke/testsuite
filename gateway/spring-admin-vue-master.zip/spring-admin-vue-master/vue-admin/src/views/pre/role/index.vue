<!--  -->
<template>
  <div>
    角色管理
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
    }
  },
  created() {},
  mounted() {},
  methods: {}
}

</script>
<style lang='scss' scoped>
</style>

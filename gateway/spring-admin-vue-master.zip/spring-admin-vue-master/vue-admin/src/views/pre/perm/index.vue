<!--  -->
<template>
  <div>
    权限管理
    <el-button v-has="'perm:new'" class="btns">添加</el-button>

    <el-button v-has="'perm:haha'" class="btns">哈哈</el-button>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
    }
  },
  created() {},
  mounted() {},
  methods: {}
}

</script>
<style lang='scss' scoped>
</style>
